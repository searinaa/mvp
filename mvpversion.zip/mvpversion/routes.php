<?php
  $result = $_SERVER['REQUEST_URI'];
  if($result == '/mvpversion/startpage.php/events') {
    include 'view/filter.php';
    include 'view/checkbox.php';
  }
  if($result == '/mvpversion/startpage.php/us') {
  }
  if($result == '/mvpversion/startpage.php/questions') {
  }
 ?>
