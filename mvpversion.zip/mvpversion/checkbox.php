<div class="checkbox">
  <ul>
  <li><input type="checkbox" name="checkbox[]" value="Gorchak"><p class="included">Горчакова</p></li>
  <li><input type="checkbox" name="checkbox[]" value="Pushkin"><p class="included">Пушкина</p></li>
  <li><input type="checkbox" name="checkbox[]" value="Pushin"><p class="included">Пущина</p></li>
  <li><input type="checkbox" name="checkbox[]" value="Delvig"><p class="included">Дельвиг</p></li>
  <li><input type="checkbox" name="checkbox[]" value="Bakunin"><p class="included">Бакунина</p></li>
  <li><input type="checkbox" name="checkbox[]" value="Korfa"><p class="included">Корфа</p></li>
  </ul>
</div>
