<div class="filter">
  <form action="" method="post">
    <input type="date" name="date">
    <input type="text" name="search">
    <?php  include_once ('checkbox.php');?>
    <input type="submit" name="submit" class="submit" value="Поиск">
  </form>
</div>
